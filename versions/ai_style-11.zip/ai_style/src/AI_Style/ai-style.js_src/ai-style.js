/* 
To compile use this command: 
npx spack entry=/src/AI_Style/ai-style.js_src/ai-style.js output=/src/AI_Style
*/
/* global cacbot_data */

import commentBoxStyle from "./CommentFormStyle";
import justifyOneLiner from "./justifyOneLiner";
import chatMessages from "./chatMessages";
import adminBarCustomization, {
  overrideHoverBehavior,
  overrideClickBehavior,
  addSidebarToggleButton,
  updateToggleButton,
  initializeZoomDetection
} from "./adminBarCustomization";
import cacbotData from "./cacbotData";
import fetchPost, { updatePostUI } from "./fetchPost";
import sidebarClick, { initSidebarClickListeners } from "./sidebarClick";
import { clearSidebar, addSidebarLink } from "./sidebarLinks";
import toggleSidebarVisible, {
  initToggleSidebar,
  toggleSidebarVisibility,
  isSidebarVisible,
  showSidebar,
  hideSidebar
} from "./toggleSidebarVisible";



document.addEventListener('DOMContentLoaded', function() {
  console.log('ai-style.js is loaded!');
  commentBoxStyle();
  justifyOneLiner();
  

  try {
    cacbotData.initialize(window.cacbot_data || {});
    window.cacbotData = cacbotData;
    console.log(cacbotData.getAll());
  } catch (error) {
    console.error("Failed to initialize cacbotData:", error);
  }
  
  // Log that the chat message functions are available
  console.log('Chat message functions are available globally:');
  console.log('- addInterlocutorMessage(message)');
  console.log('- addRespondentMessage(message)');
  
  // Initialize toggle sidebar functionality
  initToggleSidebar();
  
  // Initialize admin bar customization (includes sidebar toggle button)
  adminBarCustomization();
  
  // Set up event listeners for post navigation
  setupPostNavigation();
  initSidebarClickListeners();
  
  // Log that the toggle sidebar functions are available
  console.log('Toggle sidebar functions are available globally:');
  console.log('- toggleSidebarVisibility()');
  console.log('- isSidebarVisible()');
  console.log('- showSidebar()');
  console.log('- hideSidebar()');
  
  // Log that the admin bar customization functions are available
  console.log('Admin bar customization functions are available globally:');
  console.log('- overrideHoverBehavior(newButton)');
  console.log('- overrideClickBehavior(newButton)');
  console.log('- addSidebarToggleButton()');
  console.log('- updateToggleButton(iconElement, labelElement)');
  console.log('- initializeZoomDetection()');
  
  // Set focus to the last comment on page load
  focusLastComment();
});

/**
 * Sets up event listeners for post navigation without page refresh
 */
function setupPostNavigation() {
  console.log("anchor clicked...");
  // Listen for clicks on post links
  document.addEventListener('click', function(event) {
    // Check if the clicked element is a link to a post
    const link = event.target.closest('a');
    if (!link) return;
    
    // Check if this is an internal post link
    const href = link.getAttribute('href');
    if (!href || href.startsWith('#') || href.startsWith('http') || href.indexOf('wp-admin') !== -1) {
      return; // Not a post link or external link
    }
    
    // Try to extract post ID from the URL
    const postIdMatch = href.match(/\/(\d+)\/?$/);
    if (!postIdMatch) return; // Not a post URL with ID
    
    const postId = parseInt(postIdMatch[1], 10);
    if (isNaN(postId)) return;
    
    // Prevent default link behavior
    event.preventDefault();
    
    // Show loading indicator
    const contentArea = document.querySelector('.entry-content');
    if (contentArea) {
      contentArea.innerHTML = '<div class="loading">Loading post content...</div>';
    }
    
    // Fetch the post data
    fetchPost(postId)
      .then(postData => {
        // Update the UI with the fetched data
        updatePostUI(postData);
        
        // Scroll to top
        window.scrollTo(0, 0);
      })
      .catch(error => {
        console.error('Error navigating to post:', error);
        if (contentArea) {
          contentArea.innerHTML = `<div class="error">Error loading post: ${error.message}</div>`;
        }
      });
  });
  
  // Handle browser back/forward navigation
  window.addEventListener('popstate', function(event) {
    if (event.state && event.state.postId) {
      fetchPost(event.state.postId)
        .then(updatePostUI)
        .catch(error => {
          console.error('Error handling history navigation:', error);
        });
    }
  });
}

/**
 * Sets focus to the last comment on the page
 */
function focusLastComment() {
  // Common WordPress comment selectors
  const commentSelectors = [
    '.comment',
    '.comment-body',
    '.commentlist li',
    '#comments .comment',
    '.wp-block-comment',
    '[id^="comment-"]'
  ];
  
  let lastComment = null;
  
  // Try each selector to find comments
  for (const selector of commentSelectors) {
    const comments = document.querySelectorAll(selector);
    if (comments.length > 0) {
      lastComment = comments[comments.length - 1];
      break;
    }
  }
  
  // If we found a comment, set focus to it
  if (lastComment) {
    // Make the element focusable if it isn't already
    if (!lastComment.hasAttribute('tabindex')) {
      lastComment.setAttribute('tabindex', '-1');
    }
    
    // Set focus and scroll into view
    lastComment.focus();
    lastComment.scrollIntoView({
      behavior: 'smooth',
      block: 'center'
    });
    
    console.log('Focus set to last comment:', lastComment);
  } else {
    console.log('No comments found on the page');
  }
}