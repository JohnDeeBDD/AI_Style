<?php

namespace AI_Style;

class Comments {
 
    /**
     * Outputs the comments section for a post.
     *
     * This method is used to display comments on singular pages (posts or pages).
     * It retrieves the comments for the current post and formats them for display.
     */
    public static function echoComments() {
        // This method can be used to output comments if needed
    }
}