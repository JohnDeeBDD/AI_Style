<?php

namespace AI_Style;

class Template{

    //Code goes here
    
}