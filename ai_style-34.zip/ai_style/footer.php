<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 *
 * @package WordPress
 * @subpackage AI_Style
 */

?>
		<footer id="colophon" class="site-footer">
		Catbox can make mistakes, check important info.
		</footer><!-- .site-footer -->
</div><!-- .site -->

<?php wp_footer(); ?>

</body>
</html>